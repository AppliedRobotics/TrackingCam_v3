#include <TrackingCamDxl.h>

#define nTRACKINGCAMI2C_DEBUG
#define TRACKINGCAMI2C_DEBUG_BAUD 115200
#ifdef TRACKINGCAMI2C_DEBUG
#  define dbg_print Serial.print
#  define dbg_println Serial.println
#else
#  define dbg_print
#  define dbg_println
#endif

TrackingCamDxl::TrackingCamDxl(int aId): DynamixelDevice(aId)
{	
}

uint8_t TrackingCamDxl::readBlobs(uint8_t max_blob_n)
{
	const int blobs_per_block_n = 3;
	uint8_t resp[64];
	uint8_t n = 0;
	uint8_t idx = 5;
	uint8_t lines = max_blob_n > 10? 10: max_blob_n;

	if(lines == 0)
		lines = 1;

	for(int i = 0; i < lines; i++)
	{
		if(!(i % blobs_per_block_n))
		{
			idx = 0;
			if(read(16 + i*16, blobs_per_block_n*16, resp) != DYN_STATUS_OK) //Line by line reading
				return n; 
		}

		blob[i].type = resp[idx++];
		if(blob[i].type == 0xFF)
			return n;
		else
			n++;

		blob[i].dummy = resp[idx++];
		blob[i].cx = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].cy = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].area = (uint32_t)((((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8))) * 4;
		idx += 2;
		blob[i].left = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].right = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].top = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].bottom = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
	}
	return n;
}

uint8_t TrackingCamDxl::readObjects(uint8_t max_obj_n)
{
	const int obj_per_block_n = 4;
	uint8_t resp[64];
	uint8_t n = 0;
	uint8_t idx = 5;
	uint8_t lines = max_obj_n > 10? 10: max_obj_n;

	if(lines == 0)
		lines = 1;

	for(int i = 0; i < lines; i++)
	{
		if(!(i % obj_per_block_n))
		{
			idx = 0;
			if(read(16 + i*10, obj_per_block_n*10, resp) != DYN_STATUS_OK) //Line by line reading
				return n; 
		}
		obj[i].type = resp[idx++];
		if(obj[i].type == 0xFF)
			return n;
		else
			n++;
		obj[i].dummy = resp[idx++];
		obj[i].cx = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		obj[i].cy = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		obj[i].angle = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		obj[i].obj_size = (uint32_t)((((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8))) * 4;
		idx += 2;
	}
	return n;
}

static uint8_t TrackingCamDxl_GetCRC(uint8_t *bufData, uint8_t sizeData) 
{
	uint32_t crc32 = 0;
	for(uint16_t i = 0; i < sizeData; i++)
		crc32 += bufData[i];
	return (uint8_t)((~crc32) & 0xFF);
}